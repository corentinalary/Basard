#include <stdio.h>
#include <string.h>

int verify_password(char* flag, int len) {

    int good = 1;

    if (len > 7 || len < 7) {
        return 0;
    }

    if (flag[0] != 'a') {
        good = 0;
    }

    if (flag[1] != 's') {
        good = 0;
    }

    if (flag[2] != 't') {
        good = 0;
    }

    if (good == 0) {
        return 0;
    }

    if (flag[3] != 'i') {
        good = 0;
    }

    if (flag[4] != 'c') {
        good = 0;
    }

    if (flag[5] != 'o') {
        good = 0;
    }

    if (flag[6] != 't') {
        good = 0;
    }

    return good;
}


int main(void) {


    char password[50];

    printf("Whats the password ?\n");
    scanf("%49s", password);

    int len = strlen(password);

    if (verify_password(password, len)) {
        puts("Hey, that's the right password!\n");
    } else {
        puts("Nope !\n");
    }

    return 0;
}
