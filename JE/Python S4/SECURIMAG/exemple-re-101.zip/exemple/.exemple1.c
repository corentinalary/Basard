#include <stdio.h>
#include <string.h>

int verify_password(char* flag) {

    return !strcmp(flag, "langoustine");
}


int main(void) {


    char password[50];

    printf("Whats the password ?\n");
    scanf("%49s", password);

    if (verify_password(password)) {
        puts("Hey, that's the right password!\n");
    } else {
        puts("Nope !\n");
    }

    return 0;
}
